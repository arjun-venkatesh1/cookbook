uchiwa Cookbook CHANGELOG
=========================
This file is used to list changes made in each version of the uchiwa cookbook.

v1.2.0 (2015-11-21)
-------------------
- Bump default Uchiwa version to 0.12.1
- Use new repository URL (repositories.sensuapp.org)

v1.1.0 (2015-05-27)
-------------------
- Bump default Uchiwa version to 0.8.1
- Allow for automatic restarts when a new version is installed

v1.0.0 (2014-12-09)
-------------------
- Bump default Uchiwa version to 0.4.0

v0.7.0 (2014-12-08)
-------------------
- Set default package options (apt/dpkg/yum)
- Allow default package options to be overridden
