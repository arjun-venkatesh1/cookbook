Test cookbook for Tomcat
