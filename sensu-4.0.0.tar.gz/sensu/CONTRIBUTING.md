1. As a contributor, you agree to abide by the Code of Conduct for this project
1. Fork the repository using Github.
1. Checkout a named feature branch created from the `develop` branch.
1. Write tests using chefspec or serverspec as appropriate.
1. Complete modifications or corrections.
1. Run the tests, ensuring they all pass. (See TESTING.md)
1. Submit a Pull Request to the `develop` branch using Github.
