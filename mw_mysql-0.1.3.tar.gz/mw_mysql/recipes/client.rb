mysql_client 'default' do
  action :create
end
