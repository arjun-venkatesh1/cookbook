mw_mysql_server 'main', root_password: 'change me'
