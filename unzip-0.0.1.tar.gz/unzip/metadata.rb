name             'unzip'
maintainer       'Kirill Shevchenko'
maintainer_email 'kirills167@gmail.com'
license          'All rights reserved'
description      'Install unzip'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.0.1'
