#
# Cookbook Name:: unzip
# Recipe:: default
#

package 'unzip' do
  action :install
end
